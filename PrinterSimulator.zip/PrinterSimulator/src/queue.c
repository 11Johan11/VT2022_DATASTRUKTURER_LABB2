#include "stdlib.h"
#include "stdio.h"
#include "time.h"
#include "queue.h"

struct queue* create_queue(void)
{
	struct queue* q = (struct queue*)malloc(sizeof(struct queue));
	if (q == NULL) exit(1);
	q->front = NULL;
	q->rear = NULL;
	return q;
}

void enqueue(struct queue* q, struct task* t)
{
	struct node* n = (struct node*)malloc(sizeof(struct node));
	if (n == NULL) exit(1);
	n->next = NULL;
	n->task = t;

	//If rear is NULL (the queue is empty) then the front and the rear node is the same
	if (q->rear == NULL) {
		q->front = q->rear = n;
		return;
	}

	// Add task at the end of the queue and update rear
	q->rear->next = n;
	q->rear = n;
}

struct task* dequeue(struct queue* q)
{
	//If the queue is empty return NULL;
	if (q->front == NULL) return NULL;

	//Store the previous front and move the front node ahead
	struct node* n = q->front;

	//The new front will be the next one after the previous front
	q->front = q->front->next;

	// If front becomes NULL after dequeueing then update rear to NULL aswell;
	if (q->front == NULL) q->rear = NULL;

	return n->task;
}

void display_queue(struct queue* q)
{
	struct node* n = q->front;
	puts("TASKS IN QUEUE:");
	while (n != NULL)
	{
		printf("TASK[arrived at the %dth second, %d pages]\n", wait_time(n->task, time(NULL)), n->task->pages);
		n = n->next;
	}
}

int is_empty(struct queue* q)
{
	if (q->front == NULL) return 1;
	return 0;
}
