// Printer Simulator
// Johan Sollenius 
#include "stdio.h"
#include "stdlib.h"
#include "time.h"
#include "queue.h"
#include "task.h"
#include "printer.h"
#include "math.h"

#define MAX_TASKS 2  //Max in queue
#define PAGE_RANGE 5 //Maximum pages a task can be
#define PAGE_RATE 40 //the number of pages the printer can print in a minute
#define SIM_TIME 30 

//Returns the number of tasks in queue
int tasks_in_queue(struct queue* q);

int main()
{
    srand(time(NULL));
    struct queue* q = create_queue();

    //setting up the printer
    struct printer p;
    p.page_rate = PAGE_RATE; 
    p.time_remaining = NULL;
    p.current_task = NULL;

    int ct = time(NULL);

    for(int i = 0; i < SIM_TIME; i++)
    {
        ct++;

        //There's a 50% prob a task will be added to the queue
        if (rand()%2 && tasks_in_queue(q) < MAX_TASKS)
        {
            enqueue(q, create_task(ct, PAGE_RANGE));
        }
        
        printer_status(&p);
        display_queue(q);
        
        if (!is_busy(&p) && !is_empty(q)) //Start next printing task if the printer is not busy and the queue has a task waiting
        {
            start_next(&p, dequeue(q));
        }

        else if(is_busy(&p))
        {
            tick(&p);
        }

        printf("\n");

    }
    puts("SIMULATION ENDS");
}

int tasks_in_queue(struct queue* q)
{
    int c = 0;
    struct node* temp = q->front;
    while (temp != NULL) {

        temp = temp->next;
        c++;

    }
    return c;
}