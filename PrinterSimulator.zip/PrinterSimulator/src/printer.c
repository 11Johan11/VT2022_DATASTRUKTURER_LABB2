#include "stdlib.h"
#include "math.h"
#include "printer.h"

//do one second of printing, 
//i.e., the remaning time to complete the current task is subtracted one. 
//parameters:
//  *p, the pointer points to the printer
void tick(struct printer* p)
{
    printf("%d seconds to complete the current task\n", p->time_remaining);
    p->time_remaining--;
    if (!is_busy(p))
    {
        p->current_task = NULL;
    }
}
//check whehter the printer is printing
//parameters:
//  *p, the pointer points to the printer
//return 1 (true) or 0 (false)
int is_busy(struct printer* p)
{
    if (p->time_remaining != 0) return 1;
    return 0;
}
//start the next printing task
//parameters:
//  *p, the pointer points to the printer
//  *t, the pointer points to the printing task
void start_next(struct printer* p, struct task* t)
{
    p->current_task = t;
    p->time_remaining = ceil(60 / p->page_rate) * t->pages;
    //printf("PAGES = %d\n", t->pages);
    //printf("%d",p->time_remaining);
    
}
//display the printer's current status
//  *p, the pointer points to the printer
void printer_status(struct printer* p)
{
    if (!is_busy(p))
    {
        puts("THE PRINTER IS NO LONGER BUSY!");
    }
    else
    {
        puts("THE PRINTER IS BUSY!");
    }
}

